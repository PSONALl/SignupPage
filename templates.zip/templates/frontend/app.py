from flask import Flask, request, render_template
import datetime
import requests

BACKEND_URL = "http://0.0.0.0:9000"

app = Flask(__name__)
@app.route('/')
def home():
    day_of_week = datetime.datetime.now().strftime('%A')
    current_time = datetime.datetime.now().strftime('%H:%M:%S')
    return render_template('index.html', day_of_week=day_of_week, current_time=current_time)

@app.route('/submit', methods=['POST'])
def submit():
    form_data = dict(request.form)
    return 'Form data received: {}'.format(form_data)

@app.route('/second')
def second():
    return 'This is the second page'

if __name__ == '__main__':
    app.run(debug=True)

    # debug = True applies any changes and look for it 
    # invalid syntaxes detected