from flask import Flask, request, jsonify, render_template

from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from dotenv import load_dotenv
import os
load_dotenv()

#load env file and uri variable
MONGO_URI = os.getenv('MONGO_URI')

# Create a new client and connect to the server
client = MongoClient(MONGO_URI, server_api=ServerApi('1'))
db = client.test

# db has colllection called flask-tutorial
# if not, it will create one

collection = db['flask-tutorial']

app = Flask(__name__)

@app.route('/submit', methods=['POST'])
def submit():
    # if request.method == 'POST':
    #     username = request.form['username']
    #     password = request.form['password']
    #     return f"Success! You have submitted the form with username: {username}"
    form_data = dict(request.form)
    # it must be dict as dict is a json object in python 

    collection.insert_one(form_data)
    return 'form_data inserted into the database'
    
@app.route('/view')
def view():
    data = collection.find()

    data = list(data)

    for item in data:
        print(item)
        del item['_id']
    
    data = {
        'data': data
    }

    return data


@app.route('/api/<name>')
def api(name):
    name = request.args.get('name')
    #/api/?age=5&name=Sonali
    age = request.args.get('age')
    # request always returns a string
    # if you want to convert it to int
    # age = int(request.args.get('age'))

    return f'Hello {name}, of age {age} this is the API page'
# http://127.0.0.1:5000/api/Sonali
# http://127.0.0.1:5000/api/Sonali/5 - takes it as a whole array variable prints Sonali5


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)

    # debug = True applies any changes and look for it 
    # invalid syntaxes detected